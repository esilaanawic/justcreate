// priority: 0

console.info('Hello, World! (You will only see this line once in console, during startup)')

onEvent('item.registry', event => {
	// Register new items here
	event.create('batter', item => {
		item.displayName('Batter')
	})
	event.create('coke', item => {
		item.displayName('Coal Coke')
		item.burnTime(2400)
	})
	event.create('cookie_dough', item => {
		item.displayName('Cookie Dough')
		item.food(function(food){
			food.hunger(1)
			food.saturation(0.2)
			food.effect('minecraft:hunger', 600, 0, 0.5)
		})
	})
	event.create('steel_ingot', item => {
		item.displayName('Steel Ingot')
		item.tag('forge:ingots/steel')
	})
	event.create('steel_nugget', item => {
		item.displayName('Steel Nugget')
		item.tag('forge:nuggets/steel')
	})
	event.create('steel_sheet', item => {
		item.displayName('Steel Sheet')
		item.tag('forge:plates/steel')
	})
	event.create('diamond_shard', item => {
		item.displayName('Diamond Shard')
	})
	event.create('rough_diamond', item => {
		item.displayName('Rough Diamond')
	})
	event.create('pearl', item => {
		item.displayName('Pearl')
		item.maxStackSize(16)
	})
	event.create('incomplete_pearly_mechanism', item => {
		item.displayName('Incomplete Pearly Mechanism')
		item.maxStackSize(1)
	})
	event.create('pearly_mechanism', item => {
		item.displayName('Pearly Mechanism')
	})
})

onEvent('block.registry', event => {
	// Register new blocks here
	event.create('coke_block', block => {
		block.material('stone')
		block.hardness(5.0)
		block.displayName('Block of Coal Coke')
		block.harvestTool('pickaxe', 0)
		block.requiresTool(true)
		block.tag('minecraft:mineable/pickaxe')
		block.tagBlockAndItem('forge:storage_blocks')
	})
	event.create('steel_block', block => {
		block.material('iron')
		block.hardness(5.0)
		block.displayName('Block of Steel')
		block.harvestTool('pickaxe', 1)
		block.requiresTool(true)
		block.tag('minecraft:mineable/pickaxe')
		block.tag('minecraft:needs_stone_tool')
		block.tagBlockAndItem('forge:storage_blocks')
		block.tagBlockAndItem('forge:storage_blocks/steel')
	})
	event.create('rough_diamond_block', block => {
		block.material('iron')
		block.hardness(5.0)
		block.displayName('Block of Rough Diamond')
		block.harvestTool('pickaxe', 2)
		block.requiresTool(true)
		block.tag('minecraft:mineable/pickaxe')
		block.tag('minecraft:needs_iron_tool')
		block.tagBlockAndItem('forge:storage_blocks')
	})
	
})

//onEvent('fluid.registry', event => {
//	event.create('mushroom_stew', fluid => {
//		fluid.textureThin(0xd6c2a3)
//		fluid.bucketColor(0xd6c2a3)
//		fluid.displayName('Mushroom Stew')
//	})
//	event.create('rabbit_stew', fluid => {
//		fluid.textureThin(0xcf8d1d)
//		fluid.bucketColor(0xcf8d1d)
//		fluid.displayName('Rabbit Stew')
//	})
//	event.create('beetroot_soup', fluid => {
//		fluid.textureThin(0xcf1d4c)
//		fluid.bucketColor(0xcf1d4c)
//		fluid.displayName('Beetroot Soup')
//	})
//})

onEvent('item.modification', event => {
	// Modify existing items here
	event.modify('kubejs:coke_block', item => {
		item.setBurnTime(24000)
	})
	event.modify('minecraft:cookie', item => {
		item.setFoodProperties(function(food){
			food.fastToEat(true)
		})
	})
	event.modify('minecraft:golden_apple', item => {
		item.setMaxStackSize(1)
	})
	event.modify('minecraft:enchanted_golden_apple', item => {
		item.setMaxStackSize(1)
	})
	event.modify('minecraft:golden_carrot', item => {
		item.setMaxStackSize(1)
	})
	event.modify('quark:golden_frog_leg', item => {
		item.setMaxStackSize(1)
	})
	event.modify('minecraft:porkchop', item => {
		item.setMaxStackSize(16)
	})
	event.modify('minecraft:cooked_porkchop', item => {
		item.setMaxStackSize(16)
	})
	event.modify('minecraft:cod', item => {
		item.setMaxStackSize(16)
	})
	event.modify('minecraft:cooked_cod', item => {
		item.setMaxStackSize(16)
	})
	event.modify('minecraft:salmon', item => {
		item.setMaxStackSize(16)
	})
	event.modify('minecraft:cooked_salmon', item => {
		item.setMaxStackSize(16)
	})
	event.modify('minecraft:beef', item => {
		item.setMaxStackSize(16)
	})
	event.modify('minecraft:cooked_beef', item => {
		item.setMaxStackSize(16)
	})
	event.modify('minecraft:chicken', item => {
		item.setMaxStackSize(16)
	})
	event.modify('minecraft:cooked_chicken', item => {
		item.setMaxStackSize(16)
	})
	event.modify('minecraft:rabbit', item => {
		item.setMaxStackSize(16)
	})
	event.modify('minecraft:cooked_rabbit', item => {
		item.setMaxStackSize(16)
	})
	event.modify('minecraft:mutton', item => {
		item.setMaxStackSize(16)
	})
	event.modify('minecraft:cooked_mutton', item => {
		item.setMaxStackSize(16)
	})
	event.modify('quark:frog_leg', item => {
		item.setMaxStackSize(16)
	})
	event.modify('quark:cooked_frog_leg', item => {
		item.setMaxStackSize(16)
	})
	event.modify('quark:crab_leg', item => {
		item.setMaxStackSize(16)
	})
	event.modify('quark:cooked_crab_leg', item => {
		item.setMaxStackSize(16)
	})
	event.modify('minecraft:pufferfish', item => {
		item.setMaxStackSize(16)
	})
	event.modify('minecraft:tropical_fish', item => {
		item.setMaxStackSize(16)
	})
})