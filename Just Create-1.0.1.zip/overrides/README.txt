JUST CREATE v1.0
Inexpertly piled together by Esila Anawic

Optifine mostly works but there are a couple of rendering bugs, so use at your own risk.

MODLIST:
Name				Version				Credits
----				----				----
Appleskin			Forge 1.18-2.2.0		squeek502
Architectury			3.3.5				shedaniel
AutoRegLib			1.7-52				Vazkii
BetterAdvancements		1.18.1-0.1.2.122		way2muchnoise
Create				1.18.1_v0.4b			simibubi
EnchantmentDescriptions		Forge 1.18.1-9.0.5		DarkhaxDev
FastFurnace			1.18.1-6.0.1			Shadows_of_Fire
FastLeafDecay			27				olafskiii
FastWorkbench			1.18.1-6.0.0			Shadows_of_Fire
Ferrite Core			Forge 4.0.0			malte0811
FishInPlanks			1.18.1-0.5			ilja615_
FishingReal			1.18-1.2			PrincelessKoala
Flywheel			Forge 1.18-0.5.0		jozufozu
JEED				1.18-1.6			MehVahdJukaar
JEI				1.18.1-9.1.1.48			mezz
KubeJS				Forge 1801.4.0-build.254	LatvianModder
MouseTweaks			Forge 1.18-2.21			YaLTeR
Placebo				1.18.1-6.0.2			Shadows_of_Fire
Quark				3.0-334				Vazkii
QuarkOddities			1.18				Vazkii
RepurposedStructures		Forge 4.0.9+1.18.1		telepathicgrunt
Rhino				Forge 1800.1.6-build.81		LatvianModder
Selene				1.18-1.11			MehVahdJukaar
StorageDrawers			1.18.1-10.0.1			Texelsaur
Supplementaries			1.18.1-1.1.3			MehVahdJukaar
SwingThroughGrass		1.18.1-1.8.0			exidex
ToastControl			1.18.1-6.0.0			Shadows_of_Fire
WTHIT				Forge 4.4.0			badasintended